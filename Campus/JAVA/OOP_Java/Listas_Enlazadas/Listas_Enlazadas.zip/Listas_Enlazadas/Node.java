package OOP_Java.Listas_Enlazadas;

public class Node {
    public int value;
    public Node next = null; //Establecer next de tipo Nodo en null

    
    //Establecer en el método constructor value con un número dado
    public Node(int value) {
        this.value = value;
    }
}

