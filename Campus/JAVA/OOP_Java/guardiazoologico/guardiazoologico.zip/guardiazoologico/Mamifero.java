package OOP_Java.guardiazoologico;

public class Mamifero {
    public int energyLevel = 100;

    public int displayEnergy(){
        System.out.println("El nivel de energía es: "+ energyLevel);
        return energyLevel;
    }
}
